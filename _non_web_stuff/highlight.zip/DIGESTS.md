## Subresource Integrity

If you are loading Highlight.js via CDN you may wish to use [Subresource Integrity](https://developer.mozilla.org/en-US/docs/Web/Security/Subresource_Integrity) to guarantee that you are using a legimitate build of the library.

To do this you simply need to add the `integrity` attribute for each JavaScript file you download via CDN. These digests are used by the browser to confirm the files downloaded have not been modified.

```html
<script
  src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.10.0/highlight.min.js"
  integrity="sha384-pGqTJHE/m20W4oDrfxTVzOutpMhjK3uP/0lReY0Jq/KInpuJSXUnk4WAYbciCLqT"></script>
<!-- including any other grammars you might need to load -->
<script
  src="//cdnjs.cloudflare.com/ajax/libs/highlight.js/11.10.0/languages/go.min.js"
  integrity="sha384-Mtb4EH3R9NMDME1sPQALOYR8KGqwrXAtmc6XGxDd0XaXB23irPKsuET0JjZt5utI"></script>
```

The full list of digests for every file can be found below.

### Digests

```
sha384-qimhSkVWof5rfaFajQk8KAtzSRYyIArcJCMKWdDcNq34F4uplk08wmEyUiYLmO+3 /es/languages/c.js
sha384-5fESKgrRcGs7I/89bn7NKFcHyvIVcmQIG4JfCEAV5Rg5VVtskrmGkHVOIsD1642v /es/languages/c.min.js
sha384-yIW2CKaxiozMCGVe7a2RX90kdUjP0h2gALuNlfKbojKpQn1OmMQLGO7BOqhncFO6 /es/languages/http.js
sha384-j+2AgmE+4SlZjmviwPvbGypcb9BQNHQj043l9Bb3F2fnlusdNxxA5/INHsOrSE6g /es/languages/http.min.js
sha384-0StLGSBIhoerTxrjwG/Lx1LYO/qmSp2TzCqgzCmnBDrVmkkeaFW9vHKuLHK5Ue7H /es/languages/ini.js
sha384-Qk1583V3PAnmXJ00e8ufkLJOuIZIrqrg5sTGoghEOwikzdWrdpiJv8lQqrURXjBG /es/languages/ini.min.js
sha384-R87hRh4kF8+iz2sB6FvLrfR0XZBohjFXeJKIXld1Eji2UVi+M2+OIgJKma/9Ko6u /es/languages/json.js
sha384-QFDPNpqtrgZCuAr70TZJFM4VCY+xNnyGKwJw2EsWIBJOVcWAns9PHcLzecyDVv+x /es/languages/json.min.js
sha384-npg+R4K6p4Q5dEzYDKy3gZ+l4mGV8hDMErOZdSSvqLxED30Fhmgb54WD4wkeY5yh /es/languages/makefile.js
sha384-Ev1PV0+HiSwEbi0IfJYmpMoxv3E0sWhAALg1frIiitM9zh2BVDe871H9Z/RGXqFM /es/languages/makefile.min.js
sha384-t1qgoHZHiiSTj6BjC5oaU9wYqedDDwqUHrkKztn2/8Kvy+xxVhs58pHnUlFGWIqZ /es/languages/verilog.js
sha384-3cj0wcUVuyPZD7/NmQZVe+R/5hKUXDXlyokh6aPqJBzdN65LnXrrDuR8JJyNrKvN /es/languages/verilog.min.js
sha384-qMVhj1A6BH7PuDigiBaNE2AYrJ4mImzcMqW+ouM5938g+O7uyaP6ygZcs2uA/mr+ /es/languages/vhdl.js
sha384-mdQMmzz/pL52qaQqnXG63Jewnl+lDaXRUeF60ffBbU45RuinqP9EDGlxzyALbe+/ /es/languages/vhdl.min.js
sha384-BcjZoAx+JfnWI/YaICe1dbsNQwCCBWJKS5uLzyKKMiLTVxBqOIRmaUoiJnYADo0M /es/languages/x86asm.js
sha384-y1FgDrVkuSox/kv/Oib26ZqzunABWyUkirzc4i4sthq8Z7c/ReWp2XA9DCh7MHQh /es/languages/x86asm.min.js
sha384-WHdxyD51Y+ytDdcYGVkKHQOThUwwhLl/1GvZxHTHL4ImI4NS32L/B8bvB/1zN/Mk /languages/c.js
sha384-jtwnwOYA+K4zYN55fA4z4U0PTK5oEp4RcLYaXkYRKO3UUzge1o21ArmvKmTRdh/d /languages/c.min.js
sha384-5njNAV6cayF+v1sc70/t3BTkztvcp8TZ61d65U8YUQuXJ45PIrhcgNfccRMd9JsI /languages/http.js
sha384-ubRntct0s40ZDtDRLkxA3/xYX51o5yC2U8SKlky8dhIRsjSnvZiUKLhz0gNTewno /languages/http.min.js
sha384-l2Aa/1StxIePW3t8ALFDwO/VZShzdfn5Y+0qIFkvO4WXem4DA5+6fgKQW+w/xKEk /languages/ini.js
sha384-0/1VV9gfjl+ZuUf+R7fvp6dQlJ5JVh+WzEqjzOwd+PCh8fa104Vm13MBaJjTz+cG /languages/ini.min.js
sha384-psmmPlbfEWGyvRapexDqkVTgNz7Y1xvlGdLNWQSafI4GFQYFDXPZxVXH1laU4n6l /languages/json.js
sha384-Bb6DhE3tUpBROwypL78TbhRUs9QbCt2GxcxVSYglt2l3MefrYkm4CfwjfWhRfQaX /languages/json.min.js
sha384-Z4QQuz3ChYj9P02v2CDc+Y0OAn3iWXtJnyNd0Q6QqW4GV28viT3zcS9tYSmb9x1L /languages/makefile.js
sha384-pYbMiHWycMKEfJaSEsquFRDTjCY7QHvQN0FIfDK0lVMd9DPJuOA7Kq5wZGecvYwM /languages/makefile.min.js
sha384-1JXyk4uCVxAfcJRwRfNnpt8moDWzGVnTnXk4ucnBTXFoDyeEP1/FqjQCqgutU9nc /languages/verilog.js
sha384-i+ovBPuX6/6IYKo/hvzjiDeWmFZGjQ8GcN5P2JlCvsQQz7tmGhwFBZ7L8O5j6Uih /languages/verilog.min.js
sha384-V2Oynheqj/yMT38G4zcskFIWTJwExjl3g3gvD2a0rga9jbrWA1jdlARfXwdxDFeN /languages/vhdl.js
sha384-lRfKmfeanfEEsne7ndto0E7FFUaI9By4vEr1RZkq+pVhHu4dRKebAURBKne7Dzdm /languages/vhdl.min.js
sha384-9s/ZvqYSxQS2hJrT3LuFUwDyxlWEELd50mRuGXt0zzSwafBqEWPsv9xxNsZUF2W4 /languages/x86asm.js
sha384-cw6YAmvOjrczJAb9NkjJRzsXso0VEJrJsLZl8G49s9vVlIFVwG8cR6K8yvpDlGn5 /languages/x86asm.min.js
sha384-dZ3UicGDuOoDK9gcn5nZ0HwyX8rLrRRSWXxilTDxQdQfUT2E5P0kyldOSipBycge /highlight.js
sha384-5emaMWRLp4GGIZnyARP4wOtcc6Zrsl6DUkrd0utwA3fmyZJCzTEtypKVWxMtRt3c /highlight.min.js
```

